# JCrypto
A cryptocurrency node programmed in the Java language.
