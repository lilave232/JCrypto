/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pfinance.p2pcomm.Voting;

/**
 *
 * @author averypozzobon
 */
public class VoteType {
    public static int BLOCK = 0;
    public static int TXN = 1;
    public static int PENALTY = 2;
}
